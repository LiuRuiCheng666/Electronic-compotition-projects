module dds(
    input  clk_50M,
    input  rst_n,
    input  rx,
    output [13:0] sig_out,
    output [7:0] seg,
    output [5:0] sel,
    output baseband_out // 新增：专门给示波器 CH1 测试的 1kHz 基带输出引脚
);

    wire [31:0] data;
    wire irq;
     
    seg7_show u_seg (
         .clk(clk_50M),          
         .rst(rst_n),          
         .data(data[23:0]),  
         .seg(seg), 
         .sel(sel)  
    );

    // 1. UART 接收模块
    UartFrameRX #(.baud_rate(32'd9600)) uart_rx (
        .clk_50M   (clk_50M),
        .rst_n     (rst_n),
        .RX        (rx),
        .data_frame(data),
        .irq       (irq)
    );

    // ==================================================
    // 2. 产生 1kHz 基带序列 (0101方波) 用于 ASK/PSK 调制
    // ==================================================
    reg [15:0] bb_cnt;
    reg        bb_val;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            bb_cnt <= 16'd0;
            bb_val <= 1'b0;
        end else begin
            if (bb_cnt >= 16'd24999) begin // 50M / 50000 = 1000Hz
                bb_cnt <= 16'd0;
                bb_val <= ~bb_val;
            end else begin
                bb_cnt <= bb_cnt + 16'd1;
            end
        end
    end
    assign baseband_out = bb_val;

    // ==================================================
    // 3. 状态寄存器（解析大模式和子模式）
    // ==================================================
    reg [1:0] state;     // 提取 data[31:30]
    reg [1:0] sub_mode;  // 提取 data[25:24]
    
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            state    <= 2'd0;
            sub_mode <= 2'd0;
        end else if (irq) begin
            state    <= data[31:30]; // 00:Sin, 01:FM, 10:AM, 11:ASK/PSK
            sub_mode <= data[25:24]; // 在state==11时，00:ASK, 01:PSK
        end
    end
     
    // ==================================================
    // 4. 子模块查表地址输出与选择
    // ==================================================
    wire [11:0] sin_addr, am_c_addr, am_m_addr, fm_c_addr, fm_m_addr, ask_c_addr, psk_c_addr;
     
    reg [11:0] sel_addr_carrier, sel_addr_mod;
    always @(*) begin
        case (state)
            2'd0: begin sel_addr_carrier = sin_addr;   sel_addr_mod = 12'd0;     end  // 00: Sin
            2'd1: begin sel_addr_carrier = fm_c_addr;  sel_addr_mod = fm_m_addr; end  // 01: FM
            2'd2: begin sel_addr_carrier = am_c_addr;  sel_addr_mod = am_m_addr; end  // 10: AM
            2'd3: begin // 11: ASK 或 PSK
                if (sub_mode == 2'b00) begin
                    sel_addr_carrier = ask_c_addr;     // 00 -> ASK
                    sel_addr_mod     = 12'd0; 
                end else begin
                    sel_addr_carrier = psk_c_addr;     // 01 -> PSK
                    sel_addr_mod     = 12'd0; 
                end
            end
        endcase
    end
     
    // 共享 ROM (2个)
    wire [15:0] carrier_q, mod_q;
    ROM_Sin rom_carrier ( .address(sel_addr_carrier), .clock(clk_50M), .q(carrier_q) );
    ROM_Sin rom_mod     ( .address(sel_addr_mod),     .clock(clk_50M), .q(mod_q) );
     
    // ==================================================
    // 5. 各种波形发生模块，同时工作
    // ==================================================
    wire [13:0] sin_out;
    wire [13:0] am_out;
    wire [13:0] fm_out;
    wire [13:0] ask_out;
    wire [13:0] psk_out;

    Sin_out u_sin (
        .clk_50M(clk_50M), .rst_n(rst_n),
        .fre({1'b0, data[23:0]}),
        .addr_carrier(sin_addr),
        .carrier_data(carrier_q),
        .sig_out(sin_out)
    );

    AM_out u_am (
        .clk_50M(clk_50M), .rst_n(rst_n),
        .fre({1'b0, data[23:0]}),
        .AM_fre(25'd1000),
        .ma_step(data[29:26]),
        .addr_carrier(am_c_addr),
        .addr_mod(am_m_addr),
        .carrier_data(carrier_q),
        .mod_data(mod_q),
        .sig_out(am_out)
    );

    FM_out u_fm (
        .clk_50M(clk_50M), .n_rst(rst_n),
        .fre({1'b0, data[23:0]}),
        .FM_MOD_FRE(25'd1000),
        .FM_DEV_MODE(data[25:24]),
        .addr_carrier(fm_c_addr),
        .addr_mod(fm_m_addr),
        .carrier_data(carrier_q),
        .mod_data(mod_q),
        .sig_out(fm_out)
    );

    ASK_out u_ask(
        .clk_50M(clk_50M), .rst_n(rst_n),
        .fre({1'b0, data[23:0]}),
        .baseband(bb_val),        // 传入刚生成的内部基带序列
        .addr_carrier(ask_c_addr),
        .carrier_data(carrier_q),
        .sig_out(ask_out)
    );

    PSK_out u_psk(
        .clk_50M(clk_50M), .rst_n(rst_n),
        .fre({1'b0, data[23:0]}),
        .baseband(bb_val),        // 传入刚生成的内部基带序列
        .addr_carrier(psk_c_addr),
        .carrier_data(carrier_q),
        .sig_out(psk_out)
    );

    // ==================================================
    // 6. 根据 state 和 sub_mode 选择最终的波形输出
    // ==================================================
    reg [13:0] sig_out_r;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n)
            sig_out_r <= 14'd8192; // 默认停在 DC 中心值（无波形）
        else begin
            case (state)
                2'd0: sig_out_r <= sin_out; // 00: Sin
                2'd1: sig_out_r <= fm_out;  // 01: FM
                2'd2: sig_out_r <= am_out;  // 10: AM
                2'd3: begin                 // 11: ASK 或 PSK
                    if (sub_mode == 2'b00) 
                        sig_out_r <= ask_out;
                    else 
                        sig_out_r <= psk_out;
                end
            endcase
        end
    end

    assign sig_out = sig_out_r;

endmodule