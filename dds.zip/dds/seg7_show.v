/*
seven segment show module
2026.7.8 whu
by Zheng Zihan and DeepSeek
PIN in whu small fpga
seg[7:0]--->[C9,E9,D8,C8,D11.E8,E10,D9]
sel[5:0]--->[D12,C11,F11,G11,D14,C14]
*/

module seg7_show(
    input clk,          // 系统时钟 (例如 50MHz)
    input rst,          // 异步复位
    input [23:0] data,  // 需要显示的数据 (6位十六进制数)
    output reg [7:0] seg, // 段选信号 (a,b,c,d,e,f,g,dp)
    output reg [5:0] sel  // 6位位选信号 (控制哪一位数码管被点亮)
);

    // 扫描计数器，用于控制位选切换的速度
    reg [19:0] scan_cnt; 
    
    // 当前正在显示的 4位 十六进制数
    reg [3:0] display_digit;

    // 1. 扫描时钟分频逻辑 (约 1kHz 的扫描频率，保证不闪烁)
    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            scan_cnt <= 20'd0;
        end else begin
            scan_cnt <= scan_cnt + 1;
        end
    end

    // 2. 6位位选与数据提取逻辑
    // 假设 50MHz 时钟，scan_cnt[15:13] 可以提供一个约 1.9kHz 的 8 状态切换信号
    // 我们只取前 6 个状态来对应 6 位数码管
    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            sel <= 6'b111111; // 默认全灭 (共阴极)
            display_digit <= 4'd0;
        end else begin
            case (scan_cnt[15:13])
                3'b000: begin 
                    sel <= 6'b111110;          // 选通第 0 位 (最低位)
                    display_digit <= data[3:0];   
                end
                3'b001: begin 
                    sel <= 6'b111101;          // 选通第 1 位
                    display_digit <= data[7:4];
                end
                3'b010: begin 
                    sel <= 6'b111011;          // 选通第 2 位
                    display_digit <= data[11:8];
                end
                3'b011: begin 
                    sel <= 6'b110111;          // 选通第 3 位
                    display_digit <= data[15:12];
                end
                3'b100: begin 
                    sel <= 6'b101111;          // 选通第 4 位
                    display_digit <= data[19:16];
                end
                3'b101: begin 
                    sel <= 6'b011111;          // 选通第 5 位 (最高位)
                    display_digit <= data[23:20]; 
                end
                // 3'b110 和 3'b111 状态不处理，默认保持全灭，避免显示乱码
                default: begin
                    sel <= 6'b111111;
                    display_digit <= 4'd0;
                end
            endcase
        end
    end

    // 3. 七段译码器 (共阴极数码管)
    // 如果是共阳极，只需将输出取反 (~seg) 即可
    always @(*) begin
        case (display_digit)
            4'h0: seg = 8'h3F; // 0011 1111
            4'h1: seg = 8'h06; // 0000 0110
            4'h2: seg = 8'h5B; // 0101 1011
            4'h3: seg = 8'h4F; // 0100 1111
            4'h4: seg = 8'h66; // 0110 0110
            4'h5: seg = 8'h6D; // 0110 1101
            4'h6: seg = 8'h7D; // 0111 1101
            4'h7: seg = 8'h07; // 0000 0111
            4'h8: seg = 8'h7F; // 0111 1111
            4'h9: seg = 8'h6F; // 0110 1111
            4'hA: seg = 8'h77; // 0111 0111
            4'hB: seg = 8'h7C; // 0111 1100
            4'hC: seg = 8'h39; // 0011 1001
            4'hD: seg = 8'h5E; // 0101 1110
            4'hE: seg = 8'h79; // 0111 1001
            4'hF: seg = 8'h71; // 0111 0001
            default: seg = 8'h00;
        endcase
    end

endmodule
