module UartByteRX #(
    parameter [31:0] baud_rate = 32'd9600
)(
    input  wire       clk_50M,
    input  wire       rst_n,
    input  wire       RX,
    output reg  [7:0] data_byte,
    output reg        irq
);

    localparam integer CLK_FREQ = 50_000_000;
    localparam integer CLKS_PER_BIT = CLK_FREQ / baud_rate;       // 50M / 9600 ≈ 5208
    localparam integer HALF_BIT      = CLKS_PER_BIT / 2;          // ≈ 2604

    localparam S_IDLE  = 2'd0;
    localparam S_START = 2'd1;
    localparam S_DATA  = 2'd2;
    localparam S_STOP  = 2'd3;

    reg [1:0]  state;
    reg [31:0] cnt;
    reg [2:0]  bit_cnt;
    reg [7:0]  shift_reg;

    // ============================================================
    // 1. RX 输入同步 + 三拍多数表决滤波
    // ============================================================
    reg rx_meta;
    reg rx_sync;
    reg rx_d1;
    reg rx_d2;

    wire rx_clean;

    assign rx_clean = (rx_sync & rx_d1) |
                      (rx_sync & rx_d2) |
                      (rx_d1   & rx_d2);

    // 保存上一拍滤波后的 RX，用于检测真正下降沿
    reg rx_clean_d;

    wire start_falling_edge;
    assign start_falling_edge = (rx_clean_d == 1'b1) && (rx_clean == 1'b0);

    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            rx_meta    <= 1'b1;
            rx_sync    <= 1'b1;
            rx_d1      <= 1'b1;
            rx_d2      <= 1'b1;
            rx_clean_d <= 1'b1;
        end else begin
            rx_meta    <= RX;
            rx_sync    <= rx_meta;
            rx_d1      <= rx_sync;
            rx_d2      <= rx_d1;
            rx_clean_d <= rx_clean;
        end
    end

    // ============================================================
    // 2. UART 接收状态机：9600, 8N1
    // ============================================================
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            state      <= S_IDLE;
            cnt        <= 32'd0;
            bit_cnt    <= 3'd0;
            shift_reg  <= 8'd0;
            data_byte  <= 8'd0;
            irq        <= 1'b0;
        end else begin
            irq <= 1'b0;

            case (state)

                // ------------------------------------------------
                // 空闲状态：只响应真正的下降沿
                // ------------------------------------------------
                S_IDLE: begin
                    cnt     <= 32'd0;
                    bit_cnt <= 3'd0;

                    if (start_falling_edge) begin
                        state <= S_START;
                        cnt   <= 32'd0;
                    end
                end

                // ------------------------------------------------
                // 起始位确认：等待半个 bit，在起始位中间再次确认低电平
                // ------------------------------------------------
                S_START: begin
                    if (cnt == HALF_BIT - 1) begin
                        cnt <= 32'd0;

                        if (rx_clean == 1'b0) begin
                            state <= S_DATA;
                        end else begin
                            // 毛刺，不是真正起始位
                            state <= S_IDLE;
                        end
                    end else begin
                        cnt <= cnt + 1'b1;
                    end
                end

                // ------------------------------------------------
                // 接收 8 位数据，UART 低位先发
                // ------------------------------------------------
                S_DATA: begin
                    if (cnt == CLKS_PER_BIT - 1) begin
                        cnt <= 32'd0;

                        shift_reg[bit_cnt] <= rx_clean;

                        if (bit_cnt == 3'd7) begin
                            bit_cnt <= 3'd0;
                            state   <= S_STOP;
                        end else begin
                            bit_cnt <= bit_cnt + 1'b1;
                        end
                    end else begin
                        cnt <= cnt + 1'b1;
                    end
                end

                // ------------------------------------------------
                // 停止位检测：停止位必须为高电平才输出 irq
                // ------------------------------------------------
                S_STOP: begin
                    if (cnt == CLKS_PER_BIT - 1) begin
                        cnt   <= 32'd0;
                        state <= S_IDLE;

                        if (rx_clean == 1'b1) begin
                            data_byte <= shift_reg;
                            irq       <= 1'b1;
                        end
                    end else begin
                        cnt <= cnt + 1'b1;
                    end
                end

                default: begin
                    state <= S_IDLE;
                end

            endcase
        end
    end

endmodule