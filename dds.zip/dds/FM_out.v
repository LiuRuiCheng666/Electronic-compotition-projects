module FM_out (
    input         clk_50M, n_rst,
    input  [24:0] fre,
    input  [24:0] FM_MOD_FRE,
    input  [1:0]  FM_DEV_MODE,
    output [11:0] addr_carrier,
    output [11:0] addr_mod,
    input  [15:0] carrier_data,
    input  [15:0] mod_data,
    output [13:0] sig_out
);
    // 频偏选择：32位有符号数，彻底防止乘法溢出
    wire signed [31:0] FM_DEV_HZ = (FM_DEV_MODE==2'b00) ? 32'sd5000 : 32'sd10000;

    // ==========================================
    // 1. 调制波相位累加器 (生成1kHz基带地址)
    // ==========================================
    // 64位宽运算，保证 22517998 (2^32/50M*2^18) 常数精度不丢失
    wire [63:0] temp_m = FM_MOD_FRE * 64'd22517998;
    wire [31:0] K_m = temp_m[49:18];
    reg [31:0] phase_m;
    
    always @(posedge clk_50M or negedge n_rst) begin
        if (!n_rst) phase_m <= 32'd0;
        else        phase_m <= phase_m + K_m;
    end
    assign addr_mod = phase_m[31:20];

    // ========================================================
    // 2. FM 核心流水线：全硬件打拍，彻底杜绝时序冒险与位宽截断
    // ========================================================
    
    // 【流水线第1级】：寄存外部输入，转换调制波为有符号补码 (-8192 ~ +8191)
    reg signed [14:0] mod_r1;
    reg [31:0] FM_K_base_r1;
    reg signed [31:0] FM_K_dev_max_r1;
    
    always @(posedge clk_50M or negedge n_rst) begin
        if (!n_rst) begin
            mod_r1          <= 15'sd0;
            FM_K_base_r1    <= 32'd0;
            FM_K_dev_max_r1 <= 32'sd0;
        end else begin
            // 14位无符号转15位有符号 (-8192 ~ +8191)
            mod_r1 <= $signed({1'b0, mod_data[15:2]}) - 15'sd8192;
            
            // 中心频率的 K 值计算 (扩大位宽防止截断)
            FM_K_base_r1 <= (fre * 64'd22517998) >> 18;
            
            // 最大频偏的 K 值计算 (有符号运算)
            FM_K_dev_max_r1 <= (FM_DEV_HZ * 64'sd22517998) >>> 18;
        end
    end
    
    // 【流水线第2级】：计算实时频偏量
    reg signed [47:0] FM_dev_mul_r2;
    reg [31:0] FM_K_base_r2;
    
    always @(posedge clk_50M or negedge n_rst) begin
        if (!n_rst) begin
            FM_dev_mul_r2 <= 48'sd0;
            FM_K_base_r2  <= 32'd0;
        end else begin
            // 最大频偏步进 × 当前调制波幅度
            FM_dev_mul_r2 <= FM_K_dev_max_r1 * mod_r1;
            FM_K_base_r2  <= FM_K_base_r1; // 同步打拍，对齐时序
        end
    end
    
    // 【流水线第3级】：相加得到最终的综合频率控制字 K
    reg [31:0] FM_K_final_r3;
    
    always @(posedge clk_50M or negedge n_rst) begin
        if (!n_rst) begin
            FM_K_final_r3 <= 32'd0;
        end else begin
            // (FM_dev_mul_r2 >>> 13) 相当于除以 8192 进行归一化
            FM_K_final_r3 <= FM_K_base_r2 + (FM_dev_mul_r2 >>> 13);
        end
    end
    
    // ==========================================
    // 3. 最终 FM 载波相位累加器
    // ==========================================
    reg [31:0] phase_c;
    always @(posedge clk_50M or negedge n_rst) begin
        if (!n_rst) phase_c <= 32'd0;
        else        phase_c <= phase_c + FM_K_final_r3;
    end
    
    // 将加入了动态频偏的相位输出给 ROM 查表
    assign addr_carrier = phase_c[31:20];
    
    // ==========================================
    // 4. 载波数据输出
    // ==========================================
    assign sig_out = carrier_data[15:2];

endmodule