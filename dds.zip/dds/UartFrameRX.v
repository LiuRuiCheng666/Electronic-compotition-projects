// UartFrameRX - 接收1字节起始位01，4字节有效数据位，1字节结束位FF
// 适配 UartByteRX（clk_50M）
module UartFrameRX
#(
    parameter [31:0] baud_rate = 32'd9600
)
(
    input  wire        clk_50M,       // 与 UartByteRX 同频
    input  wire        rst_n,
    input  wire        RX,

    output reg  [31:0] data_frame,    // 4字节有效数据（小端序：先收到的在低字节）
    output reg         irq            // 帧接收完成，单周期脉冲
);

    //---------------------------- 例化字节接收器 ----------------------------
    wire        byte_irq;
    wire [7:0]  byte_data;

    UartByteRX #(
        .baud_rate(baud_rate)
    ) u_byte_rx (
        .clk_50M   (clk_50M),
        .rst_n     (rst_n),
        .RX        (RX),
        .data_byte (byte_data),
        .irq       (byte_irq)
    );

    //---------------------------- 内部寄存器 ----------------------------
    reg [31:0] data_reg;          // 暂存4个数据字节
    reg [1:0]  byte_cnt;          // 计数数据字节（0~3）
    reg        byte_irq_d;
    wire       byte_irq_pos = byte_irq & ~byte_irq_d;

    //---------------------------- 状态机 ----------------------------
    localparam IDLE      = 2'b00,
               RECV_DATA = 2'b01,
               RECV_TAIL = 2'b10;
    reg [1:0] state;

    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            state      <= IDLE;
            byte_cnt   <= 2'd0;
            data_reg   <= 32'd0;
            data_frame <= 32'd0;
            irq        <= 1'b0;
            byte_irq_d <= 1'b0;
        end else begin
            byte_irq_d <= byte_irq;
            irq        <= 1'b0;   // 默认低

            case (state)
                IDLE: begin
                    if (byte_irq_pos && byte_data == 8'h01) begin
                        // 收到正确的起始字节
                        state    <= RECV_DATA;
                        byte_cnt <= 2'd0;
                        data_reg <= 32'd0;
                    end
                    // 非起始字节则忽略，保持 IDLE
                end

                RECV_DATA: begin
                    if (byte_irq_pos) begin
                        // 小端存储：先收到的字节放在最低位
                        data_reg <= {data_reg[23:0], byte_data};
                        if (byte_cnt == 2'd3) begin
                            state <= RECV_TAIL;  // 已收到4个数据字节
                        end else begin
                            byte_cnt <= byte_cnt + 1'b1;
                        end
                    end
                end

                RECV_TAIL: begin
                    if (byte_irq_pos) begin
                        if (byte_data == 8'hFF) begin
                            data_frame <= data_reg;   // 输出有效数据
                            irq        <= 1'b1;       // 产生完成脉冲
                        end
                        // 无论结束字节是否正确，都回到 IDLE
                        state <= IDLE;
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule