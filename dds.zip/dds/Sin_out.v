module Sin_out (
    input clk_50M,
    input rst_n,
    input [24:0] fre,
    output [11:0] addr_carrier,      // 载波地址
    input [15:0] carrier_data,      // ROM数据
    output [13:0] sig_out
);
    wire [63:0] temp = fre * 64'd22517998;
	 
    wire [31:0] freq_step = temp[49:18];
	 
    reg [31:0] phase_acc;
	 
    always @(posedge clk_50M or negedge rst_n)
        if (!rst_n) phase_acc <= 0;
        else phase_acc <= phase_acc + freq_step;
	
    assign addr_carrier = phase_acc[31:20];  // 10位地址
    assign sig_out = carrier_data[15:2];
	 
endmodule
/*
module Sin_out (
	input clk_50M,
	input rst_n,
	input [24:0] fre,
	output [13:0] sig_out
);
	wire [63:0] temp = fre * 64'd22517998;
   wire [31:0] freq_step = temp[49:18];
	
	reg [31:0] phase_acc;
    
   always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            phase_acc <= 32'd0;
        end else begin
            phase_acc <= phase_acc + freq_step;
        end
    end
	 
	 wire [15:0] rom_data;

    ROM_Sin ROM_Sin_inst (
        .address ( phase_acc[31:20] ),
        .clock   ( clk_50M ),         
        .q       ( rom_data )
    );
	 
	 assign sig_out = rom_data[15:2];

endmodule
*/