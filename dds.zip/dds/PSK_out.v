module PSK_out (
    input         clk_50M, 
    input         rst_n,
    input  [24:0] fre,
    input         baseband,     // 1-bit 基带序列信号 (0或1)
    output [11:0] addr_carrier,
    input  [15:0] carrier_data,
    output [13:0] sig_out
);
    // 载波相位累加器
    wire [48:0] temp_c = fre * 25'd22517998;
    wire [31:0] K_c = {1'b0, temp_c[48:18]};
    reg [31:0] phase_c;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) phase_c <= 32'd0;
        else        phase_c <= phase_c + K_c;
    end

    // ==========================================
    // PSK 核心逻辑：
    // 基带为 1 时，相位正常；
    // 基带为 0 时，相位突变 180 度 (即加上 2^31，0x8000_0000)
    // ==========================================
    wire [31:0] phase_final = baseband ? phase_c : (phase_c + 32'h8000_0000);

    assign addr_carrier = phase_final[31:20];
    assign sig_out = carrier_data[15:2];

endmodule