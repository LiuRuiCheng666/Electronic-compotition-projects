module ASK_out (
    input         clk_50M, 
    input         rst_n,
    input  [24:0] fre,
    input         baseband,     // 1-bit 基带序列信号 (0或1)
    output [11:0] addr_carrier,
    input  [15:0] carrier_data,
    output [13:0] sig_out
);
    // 载波相位累加器 (与正弦波完全一致)
    wire [48:0] temp_c = fre * 25'd22517998;
    wire [31:0] K_c = {1'b0, temp_c[48:18]};
    reg [31:0] phase_c;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) phase_c <= 32'd0;
        else        phase_c <= phase_c + K_c;
    end
    
    assign addr_carrier = phase_c[31:20];

    // ==========================================
    // ASK 核心逻辑：
    // 基带为 1 时，输出完整的载波正弦波；
    // 基带为 0 时，输出 DC 0 偏置 (DAC 的中点值 8192)
    // ==========================================
    assign sig_out = baseband ? carrier_data[15:2] : 14'd8192;

endmodule