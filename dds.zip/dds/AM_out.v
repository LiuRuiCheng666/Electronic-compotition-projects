module AM_out (
    input         clk_50M, rst_n,
    input  [24:0] fre,
    input  [24:0] AM_fre,
    input  [3:0]  ma_step,
    output [11:0] addr_carrier,
    output [11:0] addr_mod,
    input  [15:0] carrier_data,
    input  [15:0] mod_data,
    output [13:0] sig_out
);
    // ==========================================
    // 1. 相位累加器 (扩大位宽，防止乘法截断)
    // ==========================================
    wire [63:0] temp_c = fre * 64'd22517998;
    wire [31:0] K_c = temp_c[49:18];
    reg [31:0] phase_c;

    wire [63:0] temp_m = AM_fre * 64'd22517998;
    wire [31:0] K_m = temp_m[49:18];
    reg [31:0] phase_m;

    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            phase_c <= 32'd0;
            phase_m <= 32'd0;
        end else begin
            phase_c <= phase_c + K_c;
            phase_m <= phase_m + K_m;
        end
    end

    assign addr_carrier = phase_c[31:20];
    assign addr_mod     = phase_m[31:20];

    // ========================================================
    // 消除“突刺”的核心：5级流水线设计 (Pipelining) + 饱和钳位
    // ========================================================

    // 【流水线第1级】：寄存 ROM 数据，并转为有符号补码 (-8192 ~ +8191)
    reg signed [14:0] carr_r1;
    reg signed [14:0] mod_r1;
    wire signed [15:0] ma_q12 = ma_step * 16'd410; 

    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            carr_r1 <= 15'd0;
            mod_r1  <= 15'd0;
        end else begin
            // 扩展15位防止溢出，化为纯正的有符号数
            carr_r1 <= $signed({1'b0, carrier_data[15:2]}) - 15'sd8192;
            mod_r1  <= $signed({1'b0, mod_data[15:2]}) - 15'sd8192;
        end
    end

    // 【流水线第2级】：调制波乘以系数
    reg signed [31:0] mult_mod_r2;
    reg signed [14:0] carr_r2; 
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            mult_mod_r2 <= 32'd0;
            carr_r2     <= 15'd0;
        end else begin
            mult_mod_r2 <= mod_r1 * ma_q12;
            carr_r2     <= carr_r1; // 载波也要同步打拍跟上节奏
        end
    end

    // 【流水线第3级】：生成包络，并【强制消除负包络反相突刺】
    reg signed [15:0] envelope_r3;
    reg signed [14:0] carr_r3;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            envelope_r3 <= 16'd0;
            carr_r3     <= 15'd0;
        end else begin
            carr_r3 <= carr_r2;
            
            // 包络 = 1.0 (8192) + 缩放后的调制波
            if ( ($signed(16'sd8192) + $signed(mult_mod_r2 >>> 12)) < 16'sd0 )
                envelope_r3 <= 16'sd0; // 过调幅保护，防止负数翻转载波相位！
            else
                envelope_r3 <= $signed(16'sd8192) + $signed(mult_mod_r2 >>> 12);
        end
    end

    // 【流水线第4级】：包络调制载波
    reg signed [31:0] mult_am_r4;
    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n)
            mult_am_r4 <= 32'd0;
        else
            mult_am_r4 <= envelope_r3 * carr_r3;
    end

    // 【流水线第5级】：恢复 DAC 所需输出，并【强制消除溢出尖峰】
    reg [13:0] sig_out_r5;
    wire signed [16:0] final_val = $signed(mult_am_r4 >>> 14) + 17'sd8192; // +8192直流偏置

    always @(posedge clk_50M or negedge rst_n) begin
        if (!rst_n) begin
            sig_out_r5 <= 14'd8192;
        end else begin
            // 饱和钳位：超限强制截断，绝不允许波形反折到 0 点
            if (final_val > 17'sd16383)
                sig_out_r5 <= 14'd16383;
            else if (final_val < 17'sd0)
                sig_out_r5 <= 14'd0;
            else
                sig_out_r5 <= final_val[13:0]; // 绝对平滑的安全范围
        end
    end

    // 送给顶层模块输出
    assign sig_out = sig_out_r5;

endmodule